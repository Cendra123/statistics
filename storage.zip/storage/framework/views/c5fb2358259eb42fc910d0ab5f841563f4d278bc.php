

<?php $__env->startSection('title', 'Kriteria'); ?>

<?php $__env->startSection('content-header'); ?>
<div class="content-header">
  <div class="container">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Uji Statistik <small>Versi 1.0</small></h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item"><a href="#">home</a></li>
          <li class="breadcrumb-item active">Kriteria</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main content -->
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
              <form>
                  <div class="form-group row">
                    <label for="select-uji" class="col-sm-2 col-form-label">Pilih Jenis Uji: </label>
                    <div class="col-sm-3">
                      <input class="form-control" id="select-uji">
                    </div>
                    <div class="col-sm-2"></div>
                  <!-- </div> -->
                  <!-- <div class="form-group row"> -->
                    <label for="select-var" class="col-sm-2 col-form-label">Banyak Variabel: </label>
                    <div class="col-sm-3">
                      <input class="form-control" id="select-var">
                    </div>
                  </div>
                  <button class="right btn btn-success">Cari  <i class="fa fa-search"></i></button>
              </form>
          </div>
        </div>
      </div>
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\PHP7\htdocs\statistik\private\resources\views/statistik/home.blade.php ENDPATH**/ ?>